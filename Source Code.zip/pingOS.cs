﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pingOS {
    public partial class pingOS : Form {
        public pingOS() {
            InitializeComponent();
            refreshStartMenu();
            LoadLogin();
        }  
           
        public string WindowName;
        public string CurrentTheme;
        public string Theme = "Aqua";
        public string Background = "Default";
        public List<string> OpenWindows = new List<string>();
        private string password = "pingOS";
        public string username = "Eelis";
        public bool isUsernameCorrect = false;
        public bool isPasswordCorrect = false;

        private void pictureBox1_Click(object sender, EventArgs e) {
            refreshStartMenu();
        }

        public void LoadLogin() {
            refreshStartMenu();
            WindowName = "ping Login";
            appName.Text = WindowName;
            OpenWindows.Clear();
           
            loginLoginButton.Enabled = true;
            loginTop.Enabled = true;
            loginTittle.Enabled = true;
            loginUserText.Enabled = true;
            loginUserTextBox.Enabled = true;
            loginPassText.Enabled = true;
            loginPassTextBox.Enabled = true;
            loginWindow.Enabled = true;

            loginWindow.Show();
            loginTop.Show();
            loginTittle.Show();
            loginUserText.Show();
            loginUserTextBox.Show();
            loginPassText.Show();
            loginPassTextBox.Show();
            loginLoginButton.Show();
        }

        public void Logoff() {

        }

        public void ChangeBackgraund(string BackgroundName) {
            if(BackgroundName == "Default") {
                pictureBox2.BackgroundImage = Image.FromFile("C:/Users/eelis/source/repos/pingOS/wallpaper.png");
            }

            if (BackgroundName == "bliss") {
                pictureBox2.BackgroundImage = Image.FromFile("C:/Users/eelis/source/repos/pingOS/bliss.png");
            }
        }

        public void ChangeTheme(string ThemeName) {
            if(ThemeName == "Aqua") {
                CurrentTheme = "Aqua";
                taskBar.BackColor = Color.Aqua;
                fileManagerTop.BackColor = Color.Aqua;
                settingsTop.BackColor = Color.Aqua;
                aboutWindowTop.BackColor = Color.Aqua;
                menuBar.BackColor = Color.Aqua;
                appName.BackColor = Color.Aqua; 
                NotepadTop.BackColor = Color.Aqua; 
                loginTop.BackColor = Color.Aqua; 
                pictureBox1.BackColor = Color.Aqua;
                SaveTheme();
            }

            if(ThemeName == "Midnight Green") {
                CurrentTheme = "Aqua";
                taskBar.BackColor = Color.DarkGreen;
                fileManagerTop.BackColor = Color.DarkGreen;
                settingsTop.BackColor = Color.DarkGreen;
                aboutWindowTop.BackColor = Color.DarkGreen;
                menuBar.BackColor = Color.DarkGreen;
                appName.BackColor = Color.DarkGreen;
                NotepadTop.BackColor = Color.DarkGreen;
                loginTop.BackColor = Color.DarkGreen;
                pictureBox1.BackColor = Color.DarkGreen;
                SaveTheme();
            }

            if(ThemeName == "Gold") {
                CurrentTheme = "Aqua";
                taskBar.BackColor = Color.Gold;
                fileManagerTop.BackColor = Color.Gold;
                settingsTop.BackColor = Color.Gold;
                aboutWindowTop.BackColor = Color.Gold;
                menuBar.BackColor = Color.Gold;
                appName.BackColor = Color.Gold;
                NotepadTop.BackColor = Color.Gold;
                loginTop.BackColor = Color.Gold;
                pictureBox1.BackColor = Color.Gold;
                SaveTheme();
            }
        }

        public void SaveTheme() {
            if(settingsTheme1.Checked) {

                taskBar.BackColor = Color.Aqua;
                fileManagerTop.BackColor = Color.Aqua;
                settingsTop.BackColor = Color.Aqua;
                aboutWindowTop.BackColor = Color.Aqua;
                menuBar.BackColor = Color.Aqua;
                appName.BackColor = Color.Aqua;
                NotepadTop.BackColor = Color.Aqua;
                loginTop.BackColor = Color.Aqua;
                pictureBox1.BackColor = Color.Aqua;
                shutDown.BackColor = Color.Aqua;
            }

            if (settingsTheme2.Checked) {
                taskBar.BackColor = Color.DarkGreen;
                fileManagerTop.BackColor = Color.DarkGreen;
                settingsTop.BackColor = Color.DarkGreen;
                aboutWindowTop.BackColor = Color.DarkGreen;
                menuBar.BackColor = Color.DarkGreen;
                appName.BackColor = Color.DarkGreen;
                NotepadTop.BackColor = Color.DarkGreen;
                loginTop.BackColor = Color.DarkGreen;
                pictureBox1.BackColor = Color.DarkGreen;
            }

            if (settingsTheme3.Checked) {
                taskBar.BackColor = Color.Gold;
                fileManagerTop.BackColor = Color.Gold;
                settingsTop.BackColor = Color.Gold;
                aboutWindowTop.BackColor = Color.Gold;
                menuBar.BackColor = Color.Gold;
                appName.BackColor = Color.Gold;
                NotepadTop.BackColor = Color.Gold;
                loginTop.BackColor = Color.Gold;
                pictureBox1.BackColor = Color.Gold;
            }
        }

        public void LoadDesktop() {
            refreshStartMenu();
            WindowName = "ping Login";
            appName.Text = WindowName;
            OpenWindows.Clear();

            loginLoginButton.Enabled = false;
            loginTop.Enabled = false;
            loginTittle.Enabled = false;
            loginUserText.Enabled = false;
            loginUserTextBox.Enabled = false;
            loginPassText.Enabled = false;
            loginPassTextBox.Enabled = false;
            loginWindow.Enabled = false;

            loginWindow.Hide();
            loginTop.Hide();
            loginTittle.Hide();
            loginUserText.Hide();
            loginUserTextBox.Hide();
            loginPassText.Hide();
            loginPassTextBox.Hide();
            loginLoginButton.Hide();

            // Loading The TaskBar
            startButton.Enabled = true;
            taskBar.Enabled = true;

            startButton.Show();
            taskBar.Show();
          
               
        }

        private void loginLoginButton_Click(object sender, EventArgs e) {
            if (isPasswordCorrect && isUsernameCorrect) {
                LoadDesktop();
            }
        }

        void refreshStartMenu() {                      
            
            pictureBox1.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            
            button7.Enabled = false;
            about.Enabled = false;
            shutDown.Enabled = false;
            //startMenu.Enabled = false;

            //startMenu.Hide();
            pictureBox1.Hide();
            button1.Hide();
            button2.Hide();
            button3.Hide();
            button4.Hide();
           
            button7.Hide();
            about.Hide();
            shutDown.Hide();
        }

        private void startButton_Click(object sender, EventArgs e) {
            button7.Text = "Logoff " + username;
            pictureBox1.Enabled = true;
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button7.Enabled = true;
            about.Enabled = true;
            shutDown.Enabled = true;
           // startMenu.Enabled = true;

            //startMenu.Show();
            pictureBox1.Show();
            button1.Show();
            button2.Show();
            button3.Show();
            button4.Show();
            button7.Show();
            about.Show();
            shutDown.Show();
        }

        // All Shell Components

        public void OpenWindow(string OpenWindowName) {
            OpenWindowName = WindowName;
            appName.Text = OpenWindowName;
            if(OpenWindowName == "About") {
                refreshStartMenu();

                OpenWindows.Add(OpenWindowName);

                // Open About Window
                aboutPingOSWindowX.Enabled = true;
                aboutWindow.Enabled = true;
                aboutWindowTop.Enabled = true;
                aboutLogo.Enabled = true;
                aboutText.Enabled = true;
                aboutText2.Enabled = true;

                aboutWindow.Show();
                aboutWindowTop.Show();
                aboutPingOSWindowX.Show();
                aboutLogo.Show();
                aboutText.Show();              
                aboutText2.Show();              
            }
            if (OpenWindowName == "Notepad") {
                refreshStartMenu();

                OpenWindows.Add(OpenWindowName);

                // Open Notepad Window
                NotepadWindow.Enabled = true;
                NotepadTop.Enabled = true;
                NotepadX.Enabled = true;
                notepadText.Enabled = true;
                notepadTextArea.Enabled = true;
                
                NotepadWindow.Show();
                NotepadTop.Show();
                NotepadX.Show();
                notepadText.Show();
                notepadTextArea.Show();
            
            }

            if (OpenWindowName == "File Manager") {
                refreshStartMenu();

                OpenWindows.Add(OpenWindowName);

                fileManagerTop.Enabled = true;
                fileManagerX.Enabled = true;
                fileManagerWindow.Enabled = true;

                fileManagerTop.Show();
                fileManagerX.Show();
                fileManagerWindow.Show();
            }

            if (OpenWindowName == "Quit") {
                refreshStartMenu();

                OpenWindows.Add(OpenWindowName);

                // Open Quit Window
                pictureBox3.Enabled = true;
                yesButton.Enabled = true;
                noButton.Enabled = true;
                pictureBox4.Enabled = true;
                shutDownLabel.Enabled = true;
                dosMode.Enabled = true;

                yesButton.Show();
                noButton.Show();
                pictureBox3.Show();
                pictureBox4.Show();
                shutDownLabel.Show();
                dosMode.Show();
            }

            if(OpenWindowName == "System Settings") {
                refreshStartMenu();
                OpenWindows.Add(OpenWindowName);

                settingsTheme1.Enabled = true;
                settingsTheme1.Checked = true;
                settingsTheme2.Enabled = true;
                settingsTheme2.Checked = false;
                settingsTheme3.Enabled = true;
                settingsTheme3.Checked = false;

                settingsBack1.Enabled = false;
                settingsBack1.Checked = true;
                settingsBack2.Enabled = false;
                settingsBack2.Checked = false;
               
                settingsThemeLabel.Enabled = true;
                settingsTop.Enabled = true;
                settingsX.Enabled = true;
                settingsWindow.Enabled = true;

                settingsWindow.Show();
                settingsTop.Show();
                settingsTheme1.Show();
                settingsTheme2.Show();
                settingsTheme3.Show();
                settingsThemeLabel.Show();
                settingsX.Show();

                settingsBack1.Show();
                settingsBack2.Show();
            }
        }

        public void CloseWindow(string TargetWindow) {
            appName.Text = TargetWindow;
            if (TargetWindow == "About") {
                refreshStartMenu();
                OpenWindows.Remove(TargetWindow);
                // Close About Window
                aboutPingOSWindowX.Enabled = false;
                aboutWindow.Enabled = false;
                aboutWindowTop.Enabled = false;
                aboutLogo.Enabled = true;
                aboutText.Enabled = true;
                aboutText2.Enabled = true;

                aboutWindow.Hide();
                aboutWindowTop.Hide();
                aboutPingOSWindowX.Hide();
                aboutLogo.Hide();
                aboutText.Hide();
                aboutText2.Hide();

                appName.Text = "Desktop";
            }

            if (TargetWindow == "Notepad") {
                refreshStartMenu();
                OpenWindows.Remove(TargetWindow);
                // Close Notepad Window
                NotepadWindow.Enabled = false;
                NotepadTop.Enabled = false;
                NotepadX.Enabled = false;
                notepadText.Enabled = false;
                notepadTextArea.Enabled = false;
                

                NotepadX.Hide();
                NotepadWindow.Hide();
                NotepadTop.Hide();
                notepadText.Hide();
                notepadTextArea.Hide();
                appName.Text = "Desktop";
            }

            if(TargetWindow == "File Manager") {
                refreshStartMenu();
                OpenWindows.Remove(TargetWindow);
                fileManagerTop.Enabled = false;
                fileManagerX.Enabled = false;
                fileManagerWindow.Enabled = false;

                fileManagerTop.Hide();
                fileManagerX.Hide();
                fileManagerWindow.Hide();
                appName.Text = "Desktop";
            }

            if(TargetWindow == "Quit") {
                refreshStartMenu();
                OpenWindows.Remove(TargetWindow);
                
                pictureBox3.Enabled = false;
                yesButton.Enabled = false;
                noButton.Enabled = false;
                pictureBox4.Enabled = false;
                shutDownLabel.Enabled = false;
                dosMode.Enabled = false;

                yesButton.Hide();
                noButton.Hide();
                pictureBox3.Hide();
                pictureBox4.Hide();
                shutDownLabel.Hide();
                dosMode.Hide();
                appName.Text = "Desktop";
                
            }

            if (TargetWindow == "System Settings") {
                refreshStartMenu();
                OpenWindows.Remove(TargetWindow);


                settingsTheme1.Enabled = false;         
                settingsTheme2.Enabled = false;
                settingsTheme3.Enabled = false;
                settingsThemeLabel.Enabled = false;
                settingsTop.Enabled = false;
                settingsX.Enabled = false;
                settingsWindow.Enabled = false;
                settingsBack1.Enabled = false;
                settingsBack2.Enabled = false;

                settingsWindow.Hide();
                settingsTop.Hide();
                settingsTheme1.Hide();
                settingsTheme2.Hide();
                settingsTheme3.Hide();
                settingsThemeLabel.Hide();
                settingsX.Hide();
                settingsBack1.Hide();
                settingsBack2.Hide();
            }
        }

        private void taskBar_Click(object sender, EventArgs e) {

        }

        private void shutDown_Click(object sender, EventArgs e) {
            if (OpenWindows.Count != 0)
                return;
            else {
                refreshStartMenu();
                WindowName = "Quit";
                OpenWindow(WindowName);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            if (OpenWindows.Count != 0)
                return;
            else {
                refreshStartMenu();
                WindowName = "Notepad";
               
                OpenWindow(WindowName);
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            if (OpenWindows.Count != 0)
                return;
            else {
                refreshStartMenu();
                ChangeTheme(Theme);
                WindowName = "System Settings";
                OpenWindow(WindowName);
            }
        }

        private void button3_Click(object sender, EventArgs e) {
            if (OpenWindows.Count != 0) {
                return;
            } else {
                refreshStartMenu();
                WindowName = "File Manager";

                OpenWindow(WindowName);
            }
        }

        private void button4_Click(object sender, EventArgs e) {
            if (OpenWindows.Count != 0) {
                return;
            } else {
                refreshStartMenu();
                WindowName = "About";
                
                OpenWindow(WindowName);
            }
        }

        private void Form1_Load(object sender, EventArgs e) {
            LoadLogin();
            ChangeTheme(Theme);
        }

        private void aboutWindowTop_Click(object sender, EventArgs e) {

        }

        private void aboutPingOSWindowX_Click(object sender, EventArgs e) {
            refreshStartMenu();
            WindowName = "About";
            CloseWindow(WindowName);
        }

        private void aboutWindow_Click(object sender, EventArgs e) {

        }

        private void windowName_Click(object sender, EventArgs e) {

        }

        private void NotepadTop_Click(object sender, EventArgs e) {

        }

        private void NotepadX_Click(object sender, EventArgs e) {
            refreshStartMenu();
            WindowName = "Notepad";
            CloseWindow(WindowName);
        }

        private void NotepadWindow_Click(object sender, EventArgs e) {

        }

        private void notepadText_Click(object sender, EventArgs e) {

        }

        private void notepadTextArea_TextChanged(object sender, EventArgs e) {
            notepadText.Text = notepadTextArea.Text;
        }

        private void button8_Click(object sender, EventArgs e) {

        }

        private void pictureBox4_Click(object sender, EventArgs e) {

        }

        private void button4_Click_1(object sender, EventArgs e) {

        }

        private void shutDownLabel_Click(object sender, EventArgs e) {

        }

        private void yesButton_Click(object sender, EventArgs e) {
            refreshStartMenu();
            Application.Exit();
        }

        private void noButton_Click(object sender, EventArgs e) {
            refreshStartMenu();
            WindowName = "Quit";
            CloseWindow(WindowName);
        }

        private void pictureBox3_Click(object sender, EventArgs e) {

        }

        private void button5_Click(object sender, EventArgs e) {

        }

        private void button6_Click(object sender, EventArgs e) {

        }

        private void button7_Click(object sender, EventArgs e) {
            refreshStartMenu();
            LoadLogin();
        }

        private void pictureBox2_Click(object sender, EventArgs e) {

        }

        private void aboutText2_Click(object sender, EventArgs e) {

        }

        private void aboutText_Click(object sender, EventArgs e) {

        }

        private void aboutLogo_Click(object sender, EventArgs e) {

        }

        private void fileManagerWindow_Click(object sender, EventArgs e) {

        }

        private void fileManagerX_Click(object sender, EventArgs e) {
            refreshStartMenu();
            WindowName = "File Manager";
            CloseWindow(WindowName);
        }

        private void fileManagerTop_Click(object sender, EventArgs e) {
      
        }

        private void appName_Click(object sender, EventArgs e) {

        }

        private void dosMode_Click(object sender, EventArgs e) {

        }

        private void menuBar_Click(object sender, EventArgs e) {

        }

        private void loginWindow_Click(object sender, EventArgs e) {

        }

        private void loginTittle_Click(object sender, EventArgs e) {

        }

        private void loginTop_Click(object sender, EventArgs e) {

        }

        private void loginUserText_Click(object sender, EventArgs e) {

        }

        private void loginUserTextBox_TextChanged(object sender, EventArgs e) {
            if (loginUserTextBox.Text != username)
                isUsernameCorrect = false;
                else isUsernameCorrect = true;
        }

        private void loginPassText_Click(object sender, EventArgs e) {

        }

        private void loginPassTextBox_TextChanged(object sender, EventArgs e) {
            if (loginPassTextBox.Text != password)
                isPasswordCorrect = false;
            else isPasswordCorrect = true;
        }

        private void settingsTheme2_CheckedChanged(object sender, EventArgs e) {
            Theme = "Midnight Green";
            ChangeTheme(Theme);
        }

        private void settingsTop_Click(object sender, EventArgs e) {

        }

        private void settingsWindow_Click(object sender, EventArgs e) {

        }

        private void settingsThemeLabel_Click(object sender, EventArgs e) {

        }

        private void settingsTheme1_CheckedChanged(object sender, EventArgs e) {
            Theme = "Aqua";
            ChangeTheme(Theme);
        }

        private void settingsX_Click(object sender, EventArgs e) {
            refreshStartMenu();
            WindowName = "System Settings";
            CloseWindow(WindowName);
        }

        private void settingsTheme3_CheckedChanged(object sender, EventArgs e) {
            Theme = "Gold";
            ChangeTheme(Theme);
        }

        private void settingsBack1_CheckedChanged(object sender, EventArgs e) {
            Background = "Default";
            ChangeBackgraund(Background);
        }

        private void settingsBackGround_Click(object sender, EventArgs e) {

        }

        private void settingsBack2_CheckedChanged(object sender, EventArgs e) {
            Background = "bliss";
            ChangeBackgraund(Background);
        }
    }

    
}
    