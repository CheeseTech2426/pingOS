﻿
namespace pingOS {
    partial class pingOS {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pingOS));
            this.startButton = new System.Windows.Forms.Button();
            this.taskBar = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.shutDown = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.about = new System.Windows.Forms.Button();
            this.aboutWindow = new System.Windows.Forms.PictureBox();
            this.aboutWindowTop = new System.Windows.Forms.PictureBox();
            this.aboutPingOSWindowX = new System.Windows.Forms.Button();
            this.NotepadWindow = new System.Windows.Forms.PictureBox();
            this.NotepadTop = new System.Windows.Forms.PictureBox();
            this.NotepadX = new System.Windows.Forms.Button();
            this.notepadText = new System.Windows.Forms.Label();
            this.notepadTextArea = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.yesButton = new System.Windows.Forms.Button();
            this.noButton = new System.Windows.Forms.Button();
            this.shutDownLabel = new System.Windows.Forms.Label();
            this.aboutText = new System.Windows.Forms.Label();
            this.aboutText2 = new System.Windows.Forms.Label();
            this.aboutLogo = new System.Windows.Forms.PictureBox();
            this.fileManagerWindow = new System.Windows.Forms.PictureBox();
            this.fileManagerTop = new System.Windows.Forms.PictureBox();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.fileManagerX = new System.Windows.Forms.Button();
            this.menuBar = new System.Windows.Forms.PictureBox();
            this.appName = new System.Windows.Forms.Label();
            this.dosMode = new System.Windows.Forms.Button();
            this.loginLoginButton = new System.Windows.Forms.Button();
            this.loginPassTextBox = new System.Windows.Forms.TextBox();
            this.loginUserTextBox = new System.Windows.Forms.TextBox();
            this.loginTop = new System.Windows.Forms.PictureBox();
            this.loginWindow = new System.Windows.Forms.PictureBox();
            this.loginTittle = new System.Windows.Forms.Label();
            this.loginPassText = new System.Windows.Forms.Label();
            this.loginUserText = new System.Windows.Forms.Label();
            this.settingsWindow = new System.Windows.Forms.PictureBox();
            this.settingsTop = new System.Windows.Forms.PictureBox();
            this.settingsX = new System.Windows.Forms.Button();
            this.settingsThemeLabel = new System.Windows.Forms.Label();
            this.settingsTheme1 = new System.Windows.Forms.RadioButton();
            this.settingsTheme2 = new System.Windows.Forms.RadioButton();
            this.settingsTheme3 = new System.Windows.Forms.RadioButton();
            this.settingsBack1 = new System.Windows.Forms.RadioButton();
            this.settingsBack2 = new System.Windows.Forms.RadioButton();
            this.settingsBackGround = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.taskBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aboutWindow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aboutWindowTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NotepadWindow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NotepadTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aboutLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileManagerWindow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileManagerTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginWindow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.settingsWindow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.settingsTop)).BeginInit();
            this.SuspendLayout();
            // 
            // startButton
            // 
            this.startButton.Enabled = false;
            this.startButton.Location = new System.Drawing.Point(11, 898);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(82, 30);
            this.startButton.TabIndex = 0;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Visible = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // taskBar
            // 
            this.taskBar.BackColor = System.Drawing.Color.Aqua;
            this.taskBar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.taskBar.Enabled = false;
            this.taskBar.Location = new System.Drawing.Point(-3, 891);
            this.taskBar.Name = "taskBar";
            this.taskBar.Size = new System.Drawing.Size(1394, 46);
            this.taskBar.TabIndex = 1;
            this.taskBar.TabStop = false;
            this.taskBar.Visible = false;
            this.taskBar.Click += new System.EventHandler(this.taskBar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Aqua;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Location = new System.Drawing.Point(-3, 613);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(187, 280);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // shutDown
            // 
            this.shutDown.Enabled = false;
            this.shutDown.Location = new System.Drawing.Point(11, 862);
            this.shutDown.Name = "shutDown";
            this.shutDown.Size = new System.Drawing.Size(161, 23);
            this.shutDown.TabIndex = 3;
            this.shutDown.Text = "Shutdown";
            this.shutDown.UseVisualStyleBackColor = true;
            this.shutDown.Visible = false;
            this.shutDown.Click += new System.EventHandler(this.shutDown_Click);
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(11, 623);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(162, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Notepad";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(11, 652);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(162, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "Settings";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Enabled = false;
            this.button3.Location = new System.Drawing.Point(11, 681);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(162, 23);
            this.button3.TabIndex = 7;
            this.button3.Text = "File Manager";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // about
            // 
            this.about.Enabled = false;
            this.about.Location = new System.Drawing.Point(12, 831);
            this.about.Name = "about";
            this.about.Size = new System.Drawing.Size(161, 23);
            this.about.TabIndex = 8;
            this.about.Text = "About pingOS";
            this.about.UseVisualStyleBackColor = true;
            this.about.Visible = false;
            this.about.Click += new System.EventHandler(this.button4_Click);
            // 
            // aboutWindow
            // 
            this.aboutWindow.BackColor = System.Drawing.Color.White;
            this.aboutWindow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aboutWindow.Enabled = false;
            this.aboutWindow.Location = new System.Drawing.Point(503, 356);
            this.aboutWindow.Name = "aboutWindow";
            this.aboutWindow.Size = new System.Drawing.Size(239, 142);
            this.aboutWindow.TabIndex = 9;
            this.aboutWindow.TabStop = false;
            this.aboutWindow.Visible = false;
            this.aboutWindow.Click += new System.EventHandler(this.aboutWindow_Click);
            // 
            // aboutWindowTop
            // 
            this.aboutWindowTop.BackColor = System.Drawing.Color.Aqua;
            this.aboutWindowTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aboutWindowTop.Enabled = false;
            this.aboutWindowTop.Location = new System.Drawing.Point(503, 333);
            this.aboutWindowTop.Name = "aboutWindowTop";
            this.aboutWindowTop.Size = new System.Drawing.Size(239, 23);
            this.aboutWindowTop.TabIndex = 10;
            this.aboutWindowTop.TabStop = false;
            this.aboutWindowTop.Visible = false;
            this.aboutWindowTop.Click += new System.EventHandler(this.aboutWindowTop_Click);
            // 
            // aboutPingOSWindowX
            // 
            this.aboutPingOSWindowX.Enabled = false;
            this.aboutPingOSWindowX.Location = new System.Drawing.Point(723, 333);
            this.aboutPingOSWindowX.Name = "aboutPingOSWindowX";
            this.aboutPingOSWindowX.Size = new System.Drawing.Size(19, 23);
            this.aboutPingOSWindowX.TabIndex = 11;
            this.aboutPingOSWindowX.Text = "X";
            this.aboutPingOSWindowX.UseVisualStyleBackColor = true;
            this.aboutPingOSWindowX.Visible = false;
            this.aboutPingOSWindowX.Click += new System.EventHandler(this.aboutPingOSWindowX_Click);
            // 
            // NotepadWindow
            // 
            this.NotepadWindow.BackColor = System.Drawing.Color.White;
            this.NotepadWindow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NotepadWindow.Cursor = System.Windows.Forms.Cursors.Default;
            this.NotepadWindow.Enabled = false;
            this.NotepadWindow.Location = new System.Drawing.Point(455, 228);
            this.NotepadWindow.Name = "NotepadWindow";
            this.NotepadWindow.Size = new System.Drawing.Size(347, 366);
            this.NotepadWindow.TabIndex = 13;
            this.NotepadWindow.TabStop = false;
            this.NotepadWindow.Visible = false;
            this.NotepadWindow.Click += new System.EventHandler(this.NotepadWindow_Click);
            // 
            // NotepadTop
            // 
            this.NotepadTop.BackColor = System.Drawing.Color.Aqua;
            this.NotepadTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NotepadTop.Cursor = System.Windows.Forms.Cursors.Default;
            this.NotepadTop.Enabled = false;
            this.NotepadTop.Location = new System.Drawing.Point(455, 204);
            this.NotepadTop.Name = "NotepadTop";
            this.NotepadTop.Size = new System.Drawing.Size(347, 24);
            this.NotepadTop.TabIndex = 14;
            this.NotepadTop.TabStop = false;
            this.NotepadTop.Visible = false;
            this.NotepadTop.Click += new System.EventHandler(this.NotepadTop_Click);
            // 
            // NotepadX
            // 
            this.NotepadX.Cursor = System.Windows.Forms.Cursors.Default;
            this.NotepadX.Enabled = false;
            this.NotepadX.Location = new System.Drawing.Point(783, 205);
            this.NotepadX.Name = "NotepadX";
            this.NotepadX.Size = new System.Drawing.Size(19, 23);
            this.NotepadX.TabIndex = 15;
            this.NotepadX.Text = "X";
            this.NotepadX.UseVisualStyleBackColor = true;
            this.NotepadX.Visible = false;
            this.NotepadX.Click += new System.EventHandler(this.NotepadX_Click);
            // 
            // notepadText
            // 
            this.notepadText.AutoSize = true;
            this.notepadText.Enabled = false;
            this.notepadText.Location = new System.Drawing.Point(467, 245);
            this.notepadText.Name = "notepadText";
            this.notepadText.Size = new System.Drawing.Size(38, 15);
            this.notepadText.TabIndex = 17;
            this.notepadText.Text = "label1";
            this.notepadText.Visible = false;
            this.notepadText.Click += new System.EventHandler(this.notepadText_Click);
            // 
            // notepadTextArea
            // 
            this.notepadTextArea.Enabled = false;
            this.notepadTextArea.Location = new System.Drawing.Point(467, 562);
            this.notepadTextArea.Name = "notepadTextArea";
            this.notepadTextArea.Size = new System.Drawing.Size(318, 23);
            this.notepadTextArea.TabIndex = 18;
            this.notepadTextArea.Visible = false;
            this.notepadTextArea.TextChanged += new System.EventHandler(this.notepadTextArea_TextChanged);
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(11, 710);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(162, 23);
            this.button4.TabIndex = 19;
            this.button4.Text = "Terminal";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button7
            // 
            this.button7.Enabled = false;
            this.button7.Location = new System.Drawing.Point(10, 739);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(162, 23);
            this.button7.TabIndex = 22;
            this.button7.Text = "Logoff";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Visible = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Enabled = false;
            this.pictureBox3.Location = new System.Drawing.Point(471, 352);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(306, 135);
            this.pictureBox3.TabIndex = 23;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Aqua;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Enabled = false;
            this.pictureBox4.Location = new System.Drawing.Point(471, 340);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(306, 23);
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Aqua;
            this.pictureBox2.ImageLocation = "D:\\pingOS\\wallpaper.png";
            this.pictureBox2.Location = new System.Drawing.Point(-3, -2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1394, 895);
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // yesButton
            // 
            this.yesButton.Enabled = false;
            this.yesButton.Location = new System.Drawing.Point(492, 454);
            this.yesButton.Name = "yesButton";
            this.yesButton.Size = new System.Drawing.Size(78, 23);
            this.yesButton.TabIndex = 26;
            this.yesButton.Text = "Yes";
            this.yesButton.UseVisualStyleBackColor = true;
            this.yesButton.Visible = false;
            this.yesButton.Click += new System.EventHandler(this.yesButton_Click);
            // 
            // noButton
            // 
            this.noButton.Enabled = false;
            this.noButton.Location = new System.Drawing.Point(687, 454);
            this.noButton.Name = "noButton";
            this.noButton.Size = new System.Drawing.Size(71, 23);
            this.noButton.TabIndex = 27;
            this.noButton.Text = "No";
            this.noButton.UseVisualStyleBackColor = true;
            this.noButton.Visible = false;
            this.noButton.Click += new System.EventHandler(this.noButton_Click);
            // 
            // shutDownLabel
            // 
            this.shutDownLabel.AutoSize = true;
            this.shutDownLabel.BackColor = System.Drawing.Color.White;
            this.shutDownLabel.Enabled = false;
            this.shutDownLabel.Location = new System.Drawing.Point(503, 380);
            this.shutDownLabel.Name = "shutDownLabel";
            this.shutDownLabel.Size = new System.Drawing.Size(242, 15);
            this.shutDownLabel.TabIndex = 28;
            this.shutDownLabel.Text = "Are you sure you want to shutdown pingOS?";
            this.shutDownLabel.Visible = false;
            this.shutDownLabel.Click += new System.EventHandler(this.shutDownLabel_Click);
            // 
            // aboutText
            // 
            this.aboutText.AutoSize = true;
            this.aboutText.BackColor = System.Drawing.Color.White;
            this.aboutText.Enabled = false;
            this.aboutText.Location = new System.Drawing.Point(576, 359);
            this.aboutText.Name = "aboutText";
            this.aboutText.Size = new System.Drawing.Size(82, 15);
            this.aboutText.TabIndex = 29;
            this.aboutText.Text = "About pingOS";
            this.aboutText.Visible = false;
            // 
            // aboutText2
            // 
            this.aboutText2.AutoSize = true;
            this.aboutText2.BackColor = System.Drawing.Color.White;
            this.aboutText2.Enabled = false;
            this.aboutText2.Location = new System.Drawing.Point(542, 374);
            this.aboutText2.Name = "aboutText2";
            this.aboutText2.Size = new System.Drawing.Size(153, 15);
            this.aboutText2.TabIndex = 30;
            this.aboutText2.Text = "System Software version 1.1";
            this.aboutText2.Visible = false;
            // 
            // aboutLogo
            // 
            this.aboutLogo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("aboutLogo.BackgroundImage")));
            this.aboutLogo.Enabled = false;
            this.aboutLogo.Location = new System.Drawing.Point(576, 404);
            this.aboutLogo.Name = "aboutLogo";
            this.aboutLogo.Size = new System.Drawing.Size(82, 63);
            this.aboutLogo.TabIndex = 31;
            this.aboutLogo.TabStop = false;
            this.aboutLogo.Visible = false;
            // 
            // fileManagerWindow
            // 
            this.fileManagerWindow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fileManagerWindow.Enabled = false;
            this.fileManagerWindow.Location = new System.Drawing.Point(368, 222);
            this.fileManagerWindow.Name = "fileManagerWindow";
            this.fileManagerWindow.Size = new System.Drawing.Size(514, 381);
            this.fileManagerWindow.TabIndex = 33;
            this.fileManagerWindow.TabStop = false;
            this.fileManagerWindow.Visible = false;
            this.fileManagerWindow.Click += new System.EventHandler(this.fileManagerWindow_Click);
            // 
            // fileManagerTop
            // 
            this.fileManagerTop.BackColor = System.Drawing.Color.Aqua;
            this.fileManagerTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fileManagerTop.Enabled = false;
            this.fileManagerTop.Location = new System.Drawing.Point(368, 198);
            this.fileManagerTop.Name = "fileManagerTop";
            this.fileManagerTop.Size = new System.Drawing.Size(514, 24);
            this.fileManagerTop.TabIndex = 34;
            this.fileManagerTop.TabStop = false;
            this.fileManagerTop.Visible = false;
            this.fileManagerTop.Click += new System.EventHandler(this.fileManagerTop_Click);
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // fileManagerX
            // 
            this.fileManagerX.Enabled = false;
            this.fileManagerX.Location = new System.Drawing.Point(864, 199);
            this.fileManagerX.Name = "fileManagerX";
            this.fileManagerX.Size = new System.Drawing.Size(16, 23);
            this.fileManagerX.TabIndex = 35;
            this.fileManagerX.Text = "X";
            this.fileManagerX.UseVisualStyleBackColor = true;
            this.fileManagerX.Visible = false;
            this.fileManagerX.Click += new System.EventHandler(this.fileManagerX_Click);
            // 
            // menuBar
            // 
            this.menuBar.BackColor = System.Drawing.Color.Aqua;
            this.menuBar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.menuBar.Location = new System.Drawing.Point(-7, -2);
            this.menuBar.Name = "menuBar";
            this.menuBar.Size = new System.Drawing.Size(1398, 41);
            this.menuBar.TabIndex = 36;
            this.menuBar.TabStop = false;
            this.menuBar.Click += new System.EventHandler(this.menuBar_Click);
            // 
            // appName
            // 
            this.appName.AutoSize = true;
            this.appName.BackColor = System.Drawing.Color.Aqua;
            this.appName.Font = new System.Drawing.Font("Bebas Neue", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.appName.Location = new System.Drawing.Point(44, 9);
            this.appName.Name = "appName";
            this.appName.Size = new System.Drawing.Size(65, 26);
            this.appName.TabIndex = 37;
            this.appName.Text = "Desktop";
            this.appName.Click += new System.EventHandler(this.appName_Click);
            // 
            // dosMode
            // 
            this.dosMode.Enabled = false;
            this.dosMode.Location = new System.Drawing.Point(583, 454);
            this.dosMode.Name = "dosMode";
            this.dosMode.Size = new System.Drawing.Size(89, 23);
            this.dosMode.TabIndex = 38;
            this.dosMode.Text = "DOS Mode";
            this.dosMode.UseVisualStyleBackColor = true;
            this.dosMode.Visible = false;
            this.dosMode.Click += new System.EventHandler(this.dosMode_Click);
            // 
            // loginLoginButton
            // 
            this.loginLoginButton.Location = new System.Drawing.Point(628, 516);
            this.loginLoginButton.Name = "loginLoginButton";
            this.loginLoginButton.Size = new System.Drawing.Size(75, 23);
            this.loginLoginButton.TabIndex = 39;
            this.loginLoginButton.Text = "Login";
            this.loginLoginButton.UseVisualStyleBackColor = true;
            this.loginLoginButton.Click += new System.EventHandler(this.loginLoginButton_Click);
            // 
            // loginPassTextBox
            // 
            this.loginPassTextBox.Location = new System.Drawing.Point(565, 452);
            this.loginPassTextBox.Name = "loginPassTextBox";
            this.loginPassTextBox.Size = new System.Drawing.Size(233, 23);
            this.loginPassTextBox.TabIndex = 41;
            this.loginPassTextBox.TextChanged += new System.EventHandler(this.loginPassTextBox_TextChanged);
            // 
            // loginUserTextBox
            // 
            this.loginUserTextBox.Location = new System.Drawing.Point(565, 405);
            this.loginUserTextBox.Name = "loginUserTextBox";
            this.loginUserTextBox.Size = new System.Drawing.Size(233, 23);
            this.loginUserTextBox.TabIndex = 42;
            this.loginUserTextBox.TextChanged += new System.EventHandler(this.loginUserTextBox_TextChanged);
            // 
            // loginTop
            // 
            this.loginTop.BackColor = System.Drawing.Color.Aqua;
            this.loginTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.loginTop.Location = new System.Drawing.Point(492, 304);
            this.loginTop.Name = "loginTop";
            this.loginTop.Size = new System.Drawing.Size(319, 23);
            this.loginTop.TabIndex = 43;
            this.loginTop.TabStop = false;
            this.loginTop.Click += new System.EventHandler(this.loginTop_Click);
            // 
            // loginWindow
            // 
            this.loginWindow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.loginWindow.Location = new System.Drawing.Point(492, 321);
            this.loginWindow.Name = "loginWindow";
            this.loginWindow.Size = new System.Drawing.Size(319, 230);
            this.loginWindow.TabIndex = 44;
            this.loginWindow.TabStop = false;
            this.loginWindow.Click += new System.EventHandler(this.loginWindow_Click);
            // 
            // loginTittle
            // 
            this.loginTittle.AutoSize = true;
            this.loginTittle.Location = new System.Drawing.Point(547, 348);
            this.loginTittle.Name = "loginTittle";
            this.loginTittle.Size = new System.Drawing.Size(228, 15);
            this.loginTittle.TabIndex = 45;
            this.loginTittle.Text = "Please Type Your Username And Password";
            this.loginTittle.Click += new System.EventHandler(this.loginTittle_Click);
            // 
            // loginPassText
            // 
            this.loginPassText.AutoSize = true;
            this.loginPassText.Location = new System.Drawing.Point(504, 455);
            this.loginPassText.Name = "loginPassText";
            this.loginPassText.Size = new System.Drawing.Size(57, 15);
            this.loginPassText.TabIndex = 46;
            this.loginPassText.Text = "Password";
            this.loginPassText.Click += new System.EventHandler(this.loginPassText_Click);
            // 
            // loginUserText
            // 
            this.loginUserText.AutoSize = true;
            this.loginUserText.Location = new System.Drawing.Point(504, 408);
            this.loginUserText.Name = "loginUserText";
            this.loginUserText.Size = new System.Drawing.Size(60, 15);
            this.loginUserText.TabIndex = 47;
            this.loginUserText.Text = "Username";
            this.loginUserText.Click += new System.EventHandler(this.loginUserText_Click);
            // 
            // settingsWindow
            // 
            this.settingsWindow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.settingsWindow.Enabled = false;
            this.settingsWindow.Location = new System.Drawing.Point(397, 252);
            this.settingsWindow.Name = "settingsWindow";
            this.settingsWindow.Size = new System.Drawing.Size(500, 334);
            this.settingsWindow.TabIndex = 48;
            this.settingsWindow.TabStop = false;
            this.settingsWindow.Visible = false;
            this.settingsWindow.Click += new System.EventHandler(this.settingsWindow_Click);
            // 
            // settingsTop
            // 
            this.settingsTop.BackColor = System.Drawing.Color.Aqua;
            this.settingsTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.settingsTop.Enabled = false;
            this.settingsTop.Location = new System.Drawing.Point(397, 228);
            this.settingsTop.Name = "settingsTop";
            this.settingsTop.Size = new System.Drawing.Size(500, 42);
            this.settingsTop.TabIndex = 49;
            this.settingsTop.TabStop = false;
            this.settingsTop.Visible = false;
            this.settingsTop.Click += new System.EventHandler(this.settingsTop_Click);
            // 
            // settingsX
            // 
            this.settingsX.Enabled = false;
            this.settingsX.Location = new System.Drawing.Point(879, 229);
            this.settingsX.Name = "settingsX";
            this.settingsX.Size = new System.Drawing.Size(17, 23);
            this.settingsX.TabIndex = 50;
            this.settingsX.Text = "X";
            this.settingsX.UseVisualStyleBackColor = true;
            this.settingsX.Visible = false;
            this.settingsX.Click += new System.EventHandler(this.settingsX_Click);
            // 
            // settingsThemeLabel
            // 
            this.settingsThemeLabel.AutoSize = true;
            this.settingsThemeLabel.Enabled = false;
            this.settingsThemeLabel.Location = new System.Drawing.Point(455, 286);
            this.settingsThemeLabel.Name = "settingsThemeLabel";
            this.settingsThemeLabel.Size = new System.Drawing.Size(43, 15);
            this.settingsThemeLabel.TabIndex = 53;
            this.settingsThemeLabel.Text = "Theme";
            this.settingsThemeLabel.Visible = false;
            this.settingsThemeLabel.Click += new System.EventHandler(this.settingsThemeLabel_Click);
            // 
            // settingsTheme1
            // 
            this.settingsTheme1.AutoSize = true;
            this.settingsTheme1.Enabled = false;
            this.settingsTheme1.Location = new System.Drawing.Point(430, 315);
            this.settingsTheme1.Name = "settingsTheme1";
            this.settingsTheme1.Size = new System.Drawing.Size(53, 19);
            this.settingsTheme1.TabIndex = 55;
            this.settingsTheme1.Text = "Aqua";
            this.settingsTheme1.UseVisualStyleBackColor = true;
            this.settingsTheme1.Visible = false;
            this.settingsTheme1.CheckedChanged += new System.EventHandler(this.settingsTheme1_CheckedChanged);
            // 
            // settingsTheme2
            // 
            this.settingsTheme2.AutoSize = true;
            this.settingsTheme2.Enabled = false;
            this.settingsTheme2.Location = new System.Drawing.Point(430, 338);
            this.settingsTheme2.Name = "settingsTheme2";
            this.settingsTheme2.Size = new System.Drawing.Size(108, 19);
            this.settingsTheme2.TabIndex = 56;
            this.settingsTheme2.Text = "Midnight Green";
            this.settingsTheme2.UseVisualStyleBackColor = true;
            this.settingsTheme2.Visible = false;
            this.settingsTheme2.CheckedChanged += new System.EventHandler(this.settingsTheme2_CheckedChanged);
            // 
            // settingsTheme3
            // 
            this.settingsTheme3.Enabled = false;
            this.settingsTheme3.Location = new System.Drawing.Point(430, 362);
            this.settingsTheme3.Name = "settingsTheme3";
            this.settingsTheme3.Size = new System.Drawing.Size(94, 19);
            this.settingsTheme3.TabIndex = 57;
            this.settingsTheme3.Text = "Gold";
            this.settingsTheme3.UseVisualStyleBackColor = true;
            this.settingsTheme3.Visible = false;
            this.settingsTheme3.CheckedChanged += new System.EventHandler(this.settingsTheme3_CheckedChanged);
            // 
            // settingsBack1
            // 
            this.settingsBack1.AutoSize = true;
            this.settingsBack1.Enabled = false;
            this.settingsBack1.Location = new System.Drawing.Point(611, 321);
            this.settingsBack1.Name = "settingsBack1";
            this.settingsBack1.Size = new System.Drawing.Size(63, 19);
            this.settingsBack1.TabIndex = 58;
            this.settingsBack1.TabStop = true;
            this.settingsBack1.Text = "Default";
            this.settingsBack1.UseVisualStyleBackColor = true;
            this.settingsBack1.Visible = false;
            this.settingsBack1.CheckedChanged += new System.EventHandler(this.settingsBack1_CheckedChanged);
            // 
            // settingsBack2
            // 
            this.settingsBack2.AutoSize = true;
            this.settingsBack2.Enabled = false;
            this.settingsBack2.Location = new System.Drawing.Point(609, 343);
            this.settingsBack2.Name = "settingsBack2";
            this.settingsBack2.Size = new System.Drawing.Size(48, 19);
            this.settingsBack2.TabIndex = 59;
            this.settingsBack2.TabStop = true;
            this.settingsBack2.Text = "Bliss";
            this.settingsBack2.UseVisualStyleBackColor = true;
            this.settingsBack2.Visible = false;
            this.settingsBack2.CheckedChanged += new System.EventHandler(this.settingsBack2_CheckedChanged);
            // 
            // settingsBackGround
            // 
            this.settingsBackGround.AutoSize = true;
            this.settingsBackGround.Enabled = false;
            this.settingsBackGround.Location = new System.Drawing.Point(628, 286);
            this.settingsBackGround.Name = "settingsBackGround";
            this.settingsBackGround.Size = new System.Drawing.Size(71, 15);
            this.settingsBackGround.TabIndex = 60;
            this.settingsBackGround.Text = "Background";
            this.settingsBackGround.Visible = false;
            this.settingsBackGround.Click += new System.EventHandler(this.settingsBackGround_Click);
            // 
            // pingOS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1385, 931);
            this.Controls.Add(this.settingsBackGround);
            this.Controls.Add(this.settingsBack2);
            this.Controls.Add(this.settingsBack1);
            this.Controls.Add(this.settingsX);
            this.Controls.Add(this.notepadText);
            this.Controls.Add(this.settingsThemeLabel);
            this.Controls.Add(this.settingsTheme3);
            this.Controls.Add(this.settingsTheme2);
            this.Controls.Add(this.settingsTheme1);
            this.Controls.Add(this.aboutPingOSWindowX);
            this.Controls.Add(this.aboutText);
            this.Controls.Add(this.aboutText2);
            this.Controls.Add(this.aboutLogo);
            this.Controls.Add(this.notepadTextArea);
            this.Controls.Add(this.NotepadX);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.fileManagerX);
            this.Controls.Add(this.loginLoginButton);
            this.Controls.Add(this.loginUserText);
            this.Controls.Add(this.loginPassText);
            this.Controls.Add(this.loginTittle);
            this.Controls.Add(this.loginTop);
            this.Controls.Add(this.loginUserTextBox);
            this.Controls.Add(this.loginPassTextBox);
            this.Controls.Add(this.dosMode);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.appName);
            this.Controls.Add(this.menuBar);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.shutDownLabel);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.yesButton);
            this.Controls.Add(this.noButton);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.shutDown);
            this.Controls.Add(this.about);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.taskBar);
            this.Controls.Add(this.aboutWindow);
            this.Controls.Add(this.loginWindow);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.aboutWindowTop);
            this.Controls.Add(this.fileManagerTop);
            this.Controls.Add(this.fileManagerWindow);
            this.Controls.Add(this.NotepadTop);
            this.Controls.Add(this.NotepadWindow);
            this.Controls.Add(this.settingsWindow);
            this.Controls.Add(this.settingsTop);
            this.Controls.Add(this.pictureBox2);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1401, 970);
            this.MinimumSize = new System.Drawing.Size(1401, 970);
            this.Name = "pingOS";
            this.Text = "pingOS";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.taskBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aboutWindow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aboutWindowTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NotepadWindow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NotepadTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aboutLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileManagerWindow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileManagerTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginWindow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.settingsWindow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.settingsTop)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.PictureBox taskBar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button shutDown;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button about;
        private System.Windows.Forms.PictureBox aboutWindow;
        private System.Windows.Forms.PictureBox aboutWindowTop;
        private System.Windows.Forms.Button aboutPingOSWindowX;
        private System.Windows.Forms.PictureBox NotepadWindow;
        private System.Windows.Forms.PictureBox NotepadTop;
        private System.Windows.Forms.Button NotepadX;
        private System.Windows.Forms.Label notepadText;
        private System.Windows.Forms.TextBox notepadTextArea;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button yesButton;
        private System.Windows.Forms.Button noButton;
        private System.Windows.Forms.Label shutDownLabel;
        private System.Windows.Forms.Label aboutText;
        private System.Windows.Forms.Label aboutText2;
        private System.Windows.Forms.PictureBox aboutLogo;
        private System.Windows.Forms.PictureBox fileManagerWindow;
        private System.Windows.Forms.PictureBox fileManagerTop;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.Button fileManagerX;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label appName;
        private System.Windows.Forms.PictureBox menuBar;
        private System.Windows.Forms.Button dosMode;
        private System.Windows.Forms.Button loginLoginButton;
        private System.Windows.Forms.Label loginUserText;
        private System.Windows.Forms.Label loginPassText;
        private System.Windows.Forms.Label loginTittle;
        private System.Windows.Forms.PictureBox loginTop;
        private System.Windows.Forms.TextBox loginUserTextBox;
        private System.Windows.Forms.TextBox loginPassTextBox;
        private System.Windows.Forms.PictureBox loginWindow;
        private System.Windows.Forms.RadioButton settingsTheme3;
        private System.Windows.Forms.RadioButton settingsTheme2;
        private System.Windows.Forms.RadioButton settingsTheme1;
        private System.Windows.Forms.Label settingsThemeLabel;
        private System.Windows.Forms.Button settingsX;
        private System.Windows.Forms.PictureBox settingsWindow;
        private System.Windows.Forms.PictureBox settingsTop;
        private System.Windows.Forms.Label settingsBackGround;
        private System.Windows.Forms.RadioButton settingsBack2;
        private System.Windows.Forms.RadioButton settingsBack1;
    }
}

